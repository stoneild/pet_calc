var structfunc__map =
[
    [ "code", "structfunc__map.html#a93ba8fd6dcb3564474a70c982847104d", null ],
    [ "name", "structfunc__map.html#a13a39a34050578c4b7e95d9515e3d47d", null ],
    [ "weight", "structfunc__map.html#aba9316deadfe398099d2e5d0650a3a12", null ]
];