var annotated_dup =
[
    [ "credit_result_struct", "structcredit__result__struct.html", "structcredit__result__struct" ],
    [ "deposit_result_struct", "structdeposit__result__struct.html", "structdeposit__result__struct" ],
    [ "func_map", "structfunc__map.html", "structfunc__map" ],
    [ "operation_map", "structoperation__map.html", "structoperation__map" ],
    [ "stack", "structstack.html", "structstack" ]
];