var structdeposit__result__struct =
[
    [ "accrued_interest", "structdeposit__result__struct.html#a8fb2ca9ab38be957cbc229005a1d1730", null ],
    [ "final_amount", "structdeposit__result__struct.html#a6a8a7071f2cf9a8ae52f1adde837722a", null ],
    [ "tax_amount", "structdeposit__result__struct.html#a93bf7d08fcbf57499b9cc83e9641f30f", null ]
];