var structstack =
[
    [ "next", "structstack.html#a6f0c4fc768c3baa72d3ac9466defd42c", null ],
    [ "value", "structstack.html#a3329a8ea0abd031389f87fffb025ca40", null ],
    [ "weight", "structstack.html#a352aa19d439331702b50616f7232faa8", null ]
];