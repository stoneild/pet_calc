var searchData=
[
  ['stack_0',['stack',['../structstack.html',1,'']]]
];
