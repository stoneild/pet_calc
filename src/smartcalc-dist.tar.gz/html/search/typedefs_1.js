var searchData=
[
  ['deposit_5fresult_5fstruct_0',['deposit_result_struct',['../s21__calc_8h.html#a95c4be8f035f5c5eafd167951c2ee498',1,'s21_calc.h']]]
];
