var searchData=
[
  ['credit_5fresult_5fstruct_0',['credit_result_struct',['../structcredit__result__struct.html',1,'']]]
];
