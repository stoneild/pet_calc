var searchData=
[
  ['ln_0',['LN',['../s21__calc_8h.html#a9239321da94853834c18e339f382d9fc',1,'s21_calc.h']]],
  ['log_1',['LOG',['../s21__calc_8h.html#a159ca84d25a5487d8e81e4438725df19',1,'s21_calc.h']]]
];
