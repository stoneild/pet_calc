var searchData=
[
  ['tax_5famount_0',['tax_amount',['../structdeposit__result__struct.html#a93bf7d08fcbf57499b9cc83e9641f30f',1,'deposit_result_struct']]],
  ['total_5fpayment_1',['total_payment',['../structcredit__result__struct.html#ab8748c6e4047c642e88cfbe4abcc8c74',1,'credit_result_struct']]]
];
