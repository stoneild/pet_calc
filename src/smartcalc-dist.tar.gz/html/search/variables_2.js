var searchData=
[
  ['final_5famount_0',['final_amount',['../structdeposit__result__struct.html#a6a8a7071f2cf9a8ae52f1adde837722a',1,'deposit_result_struct']]],
  ['function_1',['function',['../structoperation__map.html#aae4be5257450f3f0dd7e3d4ca13f69b8',1,'operation_map']]]
];
