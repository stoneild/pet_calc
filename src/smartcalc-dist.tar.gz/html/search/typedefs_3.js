var searchData=
[
  ['operation_5fmap_0',['operation_map',['../s21__calc_8h.html#a80ff8316bd832e27a5a48d35d2f89b6f',1,'s21_calc.h']]]
];
