var searchData=
[
  ['name_0',['name',['../structfunc__map.html#a13a39a34050578c4b7e95d9515e3d47d',1,'func_map']]],
  ['next_1',['next',['../structstack.html#a6f0c4fc768c3baa72d3ac9466defd42c',1,'stack']]]
];
