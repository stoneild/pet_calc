var searchData=
[
  ['neg_0',['NEG',['../s21__calc_8h.html#aa27c29fc6f203aac29fb3632a0bafda5',1,'s21_calc.h']]]
];
