var s21__credit_8c =
[
    [ "calc_credit", "s21__credit_8c.html#ade5305d2b80c168b7b3068338313a634", null ],
    [ "free_credit_result", "s21__credit_8c.html#a0f769397c37dbd2c19502cfa4398de73", null ]
];