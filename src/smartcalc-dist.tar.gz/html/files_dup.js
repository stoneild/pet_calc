var files_dup =
[
    [ "s21_calc.c", "s21__calc_8c.html", "s21__calc_8c" ],
    [ "s21_calc.h", "s21__calc_8h.html", "s21__calc_8h" ],
    [ "s21_credit.c", "s21__credit_8c.html", "s21__credit_8c" ],
    [ "s21_deposit.c", "s21__deposit_8c.html", "s21__deposit_8c" ],
    [ "s21_op.c", "s21__op_8c.html", "s21__op_8c" ],
    [ "s21_stack.c", "s21__stack_8c.html", "s21__stack_8c" ]
];