var s21__op_8c =
[
    [ "s21_acos", "s21__op_8c.html#af152c85dba4fbdaa743bbcc4f9e623d8", null ],
    [ "s21_add", "s21__op_8c.html#abd657563f17603277fcafccc8fb53f78", null ],
    [ "s21_asin", "s21__op_8c.html#a19aaaad1d7c0c53c27dbb06377ea7f5d", null ],
    [ "s21_atan", "s21__op_8c.html#a1a28e6221a9b6d17c3db21bac320f979", null ],
    [ "s21_cos", "s21__op_8c.html#a1ad68365f7cc2a5f62dfeb7dfc7a3f9b", null ],
    [ "s21_div", "s21__op_8c.html#acadec9f044a62732ff264348f6e05aa9", null ],
    [ "s21_ln", "s21__op_8c.html#a288c3cc002db8b6e908b67a42de5c048", null ],
    [ "s21_log", "s21__op_8c.html#a9fbb7d0a3974c9b8bf18f7c262501472", null ],
    [ "s21_mod", "s21__op_8c.html#a64f2ad42e29885c78aef80692b7b76c2", null ],
    [ "s21_mul", "s21__op_8c.html#a06f8f4021cce2b0d4007b3e86c4e2411", null ],
    [ "s21_neg", "s21__op_8c.html#a835357e6213d7e04bb768a7112ede3ab", null ],
    [ "s21_pos", "s21__op_8c.html#abf8ae07b6048cb672c3040b9439b1865", null ],
    [ "s21_pow", "s21__op_8c.html#abfc4e70a8499ed7760f15e3cfb34b6fa", null ],
    [ "s21_sin", "s21__op_8c.html#ae6fdab8312da990868ca32c108a1b9dd", null ],
    [ "s21_sqrt", "s21__op_8c.html#a8c49e2a30b9731387c8164e626da5c9a", null ],
    [ "s21_sub", "s21__op_8c.html#a865074c5ab7837cac4c857c165aaa048", null ],
    [ "s21_tan", "s21__op_8c.html#ae1451a2e5cec7cd742edf55c97112f01", null ]
];