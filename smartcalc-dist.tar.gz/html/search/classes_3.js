var searchData=
[
  ['operation_5fmap_0',['operation_map',['../structoperation__map.html',1,'']]]
];
