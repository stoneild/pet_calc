var searchData=
[
  ['func_5fmap_0',['func_map',['../s21__calc_8h.html#a2d9d7551ad3e58171bd14124b5136f78',1,'s21_calc.h']]]
];
