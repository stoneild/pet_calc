var searchData=
[
  ['sin_0',['SIN',['../s21__calc_8h.html#ac80ce9955a1af2ab7aa3a67251ec9f5c',1,'s21_calc.h']]],
  ['sqrt_1',['SQRT',['../s21__calc_8h.html#a095e93222540fb38e433670cf08b5a46',1,'s21_calc.h']]],
  ['sub_2',['SUB',['../s21__calc_8h.html#a62c52d6d320f53e9e6632cce5a595660',1,'s21_calc.h']]]
];
