var searchData=
[
  ['tan_0',['TAN',['../s21__calc_8h.html#a3f6118fca436bd2827d5fd0f998f665d',1,'s21_calc.h']]],
  ['tax_5famount_1',['tax_amount',['../structdeposit__result__struct.html#a93bf7d08fcbf57499b9cc83e9641f30f',1,'deposit_result_struct']]],
  ['total_5fpayment_2',['total_payment',['../structcredit__result__struct.html#ab8748c6e4047c642e88cfbe4abcc8c74',1,'credit_result_struct']]]
];
