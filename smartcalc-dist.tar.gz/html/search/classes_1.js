var searchData=
[
  ['deposit_5fresult_5fstruct_0',['deposit_result_struct',['../structdeposit__result__struct.html',1,'']]]
];
