var searchData=
[
  ['free_5fcredit_5fresult_0',['free_credit_result',['../s21__calc_8h.html#a0f769397c37dbd2c19502cfa4398de73',1,'free_credit_result(credit_result_struct *result):&#160;s21_credit.c'],['../s21__credit_8c.html#a0f769397c37dbd2c19502cfa4398de73',1,'free_credit_result(credit_result_struct *result):&#160;s21_credit.c']]],
  ['free_5fstack_1',['free_stack',['../s21__calc_8c.html#a275f63bb15637cc8d62b10bf4ec1622d',1,'free_stack(struct stack **stack):&#160;s21_calc.c'],['../s21__calc_8h.html#a275f63bb15637cc8d62b10bf4ec1622d',1,'free_stack(struct stack **stack):&#160;s21_calc.c']]]
];
