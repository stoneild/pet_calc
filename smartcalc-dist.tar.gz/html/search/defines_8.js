var searchData=
[
  ['tan_0',['TAN',['../s21__calc_8h.html#a3f6118fca436bd2827d5fd0f998f665d',1,'s21_calc.h']]]
];
