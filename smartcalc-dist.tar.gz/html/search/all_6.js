var searchData=
[
  ['name_0',['name',['../structfunc__map.html#a13a39a34050578c4b7e95d9515e3d47d',1,'func_map']]],
  ['neg_1',['NEG',['../s21__calc_8h.html#aa27c29fc6f203aac29fb3632a0bafda5',1,'s21_calc.h']]],
  ['next_2',['next',['../structstack.html#a6f0c4fc768c3baa72d3ac9466defd42c',1,'stack']]]
];
