var searchData=
[
  ['value_0',['value',['../structstack.html#a3329a8ea0abd031389f87fffb025ca40',1,'stack']]]
];
