var searchData=
[
  ['operation_5fmap_0',['operation_map',['../structoperation__map.html',1,'operation_map'],['../s21__calc_8h.html#a80ff8316bd832e27a5a48d35d2f89b6f',1,'operation_map:&#160;s21_calc.h']]],
  ['overpayment_1',['overpayment',['../structcredit__result__struct.html#a0dee96e9fe00f9b651d336c49485811f',1,'credit_result_struct']]]
];
