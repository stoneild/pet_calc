var s21__stack_8c =
[
    [ "destroy_lexeme", "s21__stack_8c.html#a2eac3797379c0b592e6dc26db0ae2cdd", null ],
    [ "pop_lexeme", "s21__stack_8c.html#aac1aab0a6d2640a2f083b46f54e8862f", null ],
    [ "push_lexeme", "s21__stack_8c.html#aea17b36a516eda242bcc99df0779f606", null ],
    [ "push_new_lexeme", "s21__stack_8c.html#a7f037b4a7dfe5ef77192d950a1dce123", null ]
];