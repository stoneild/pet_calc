var structoperation__map =
[
    [ "code", "structoperation__map.html#a983c3e4c5c31c9dedd1f6b15df4623cf", null ],
    [ "function", "structoperation__map.html#aae4be5257450f3f0dd7e3d4ca13f69b8", null ]
];