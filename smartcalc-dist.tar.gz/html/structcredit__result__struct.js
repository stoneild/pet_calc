var structcredit__result__struct =
[
    [ "monthly_payments", "structcredit__result__struct.html#a49020190fd3aaa40ced6954a5f20819c", null ],
    [ "months", "structcredit__result__struct.html#a0880ae73c00cf9ce29e272dffc3c96d2", null ],
    [ "overpayment", "structcredit__result__struct.html#a0dee96e9fe00f9b651d336c49485811f", null ],
    [ "total_payment", "structcredit__result__struct.html#ab8748c6e4047c642e88cfbe4abcc8c74", null ]
];